<?php



function add_xz_box (){
	//添加设置区域的函数a
	add_meta_box('xz_box_1', '百度地图坐标设置', 'xz_box_1','post','advanced','default');
}
//在'add_meta_boxes'挂载 add_xz_box 函数
add_action('add_meta_boxes','add_xz_box');
function xz_box_1($post){
	
	
	//显示设置区域的回调函数echo"add_meta_box 测试";
  $xpos = get_post_meta( $post->ID, 'xpos', true );
    $ypos = get_post_meta( $post->ID, 'ypos', true );

?>
 <label for="pos"></label>
      <span>X坐标：</span> <input type="text" id="xpos" name="xpos" value="<?php echo esc_attr( $xpos ); ?>" placeholder="输入X轴坐标">
      <span>Y坐标：</span> <input type="text" id="ypos" name="ypos" value="<?php echo esc_attr( $ypos ); ?>" placeholder="输入Y轴坐标"> 
	   
<?php
}


add_action( 'save_post', 'save_meta_box' );
function save_meta_box($post_id){

  
    if ( ! isset( $_POST['xpos'] )||!isset($_POST['ypos']) ) {
        return;
    }
    $xpos = sanitize_text_field( $_POST['xpos'] );
	  $ypos = sanitize_text_field( $_POST['ypos'] );
    update_post_meta( $post_id,'xpos', $xpos );
	update_post_meta( $post_id,'ypos', $ypos );
}

function myshortcode_function($atts, $content = null ){ // $atts 代表了 shortcode 的各个参数，$content 为标签内的内容
//定义数据库全局变量
 global $wpdb;


  extract(shortcode_atts(// 使用 extract 函数解析标签内的参数
  array( 
"appk"=>get_option("appk")
  ), $atts));

  // 返回内容
$contents='<style type="text/css">
	body, html,#allmap {width: 100%;height: 100%;overflow: hidden;margin:0;font-family:"微软雅黑";}
	.myshortcode{height:500px;width:100%;}
	</style>
	<script type="text/javascript" src="//api.map.baidu.com/api?type=webgl&v=1.0&ak='.$appk.'"></script>



	<div id="allmap"></div>

<script type="text/javascript">
    // GL版命名空间为BMapGL
	var map = new BMapGL.Map("allmap");    // 创建Map实例
	map.centerAndZoom(new BMapGL.Point(116.404, 39.928), 5);  // 初始化地图,设置中心点坐标和地图级别
	map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放
	map.setMapType(BMAP_SATELLITE_MAP);      // 设置地图类型为地球模式
	';

$sql="select distinct(post_id) from ".$wpdb->prefix."postmeta  where (meta_key='xpos' or meta_key='ypos' )and meta_value>0";
$results=$wpdb->get_results($sql);
if(!empty($results)){
	foreach ($results as $key=>$item) {
		$id=$item->post_id;
		$title = get_post($id)->post_title;
		$xpos=get_post_meta($id, "xpos", true);
			$ypos=get_post_meta($id, "ypos", true);
	
$contents.='
// 创建点标记
	var point'.$key.' = new BMapGL.Point('.$xpos.', '.$ypos.');
map.centerAndZoom(point'.$key.', 15);
var marker'.$key.' = new BMapGL.Marker(point'.$key.');
map.addOverlay(marker'.$key.');
// 创建信息窗口
var opts'.$key.' = {
    width: 200,
    height: 50,
    title: "'.$title.'"
};
var infoWindow'.$key.' = new BMapGL.InfoWindow("", opts'.$key.');
// 点标记添加点击事件
marker'.$key.'.addEventListener("click", function () {
    map.openInfoWindow(infoWindow'.$key.', point'.$key.'); // 开启信息窗口
})';	
		
		
		
		
	}
}

$contents.='</script>';
  return '<div class="myshortcode">' .$contents . ' </div>' ;

}

 

add_shortcode( "baidumap" , "myshortcode_function" ); 


?>